typo3cms-installer
===================

Yet another TYPO3 CMS Composer installer
